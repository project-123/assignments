package com.capgemini.ccm.test;

import com.capgemini.ccm.service.CricketerServiceImpl;

public class TestCricketerService {

	public static void main(String[] args) {
		CricketerServiceImpl csi=new CricketerServiceImpl();
	}
}
