package com.capgemini.ccm.exception;

public class CricketerException extends RuntimeException {
	
	public CricketerException()
	{
		super();
	}

	public CricketerException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CricketerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public CricketerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CricketerException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
