package com.capgemini.ccm.util;

import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil {

	public static Connection getConnection() throws SQLException
	{
		
		OracleDataSource ods=new OracleDataSource();
		ods.setUser("Labg103trg1");
		ods.setPassword("labg103oracle");
		ods.setDriverType("thin");
		ods.setNetworkProtocol("tcp");
		ods.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
		return ods.getConnection();
		
	}
}
