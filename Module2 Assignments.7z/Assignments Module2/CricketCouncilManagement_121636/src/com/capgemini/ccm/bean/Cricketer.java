package com.capgemini.ccm.bean;

import java.sql.Date;

public class Cricketer {
	private int id;
	private String name;
	private Date DateOfBirth;
	private String country;
	private String battingStyle;
	private int centuries;
	private int matches;
	private int totalRunScore;
	
	
	public Cricketer() {
		super();
	}


	public Cricketer(int id, String name, Date dateOfBirth, String country,
			String battingStyle, int centuries, int matches, int totalRunScore) {
		super();
		this.id = id;
		this.name = name;
		DateOfBirth = dateOfBirth;
		this.country = country;
		this.battingStyle = battingStyle;
		this.centuries = centuries;
		this.matches = matches;
		this.totalRunScore = totalRunScore;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getDateOfBirth() {
		return DateOfBirth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getBattingStyle() {
		return battingStyle;
	}


	public void setBattingStyle(String battingStyle) {
		this.battingStyle = battingStyle;
	}


	public int getCenturies() {
		return centuries;
	}


	public void setCenturies(int centuries) {
		this.centuries = centuries;
	}


	public int getMatches() {
		return matches;
	}


	public void setMatches(int matches) {
		this.matches = matches;
	}


	public int getTotalRunScore() {
		return totalRunScore;
	}


	public void setTotalRunScore(int totalRunScore) {
		this.totalRunScore = totalRunScore;
	}


	@Override
	public String toString() {
		return "Cricketer [id=" + id + ", name=" + name + ", DateOfBirth="
				+ DateOfBirth + ", country=" + country + ", battingStyle="
				+ battingStyle + ", centuries=" + centuries + ", matches="
				+ matches + ", totalRunScore=" + totalRunScore + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((DateOfBirth == null) ? 0 : DateOfBirth.hashCode());
		result = prime * result
				+ ((battingStyle == null) ? 0 : battingStyle.hashCode());
		result = prime * result + centuries;
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + id;
		result = prime * result + matches;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + totalRunScore;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cricketer other = (Cricketer) obj;
		if (DateOfBirth == null) {
			if (other.DateOfBirth != null)
				return false;
		} else if (!DateOfBirth.equals(other.DateOfBirth))
			return false;
		if (battingStyle == null) {
			if (other.battingStyle != null)
				return false;
		} else if (!battingStyle.equals(other.battingStyle))
			return false;
		if (centuries != other.centuries)
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (id != other.id)
			return false;
		if (matches != other.matches)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (totalRunScore != other.totalRunScore)
			return false;
		return true;
	}


	

	
	
	
	
	
		
}
