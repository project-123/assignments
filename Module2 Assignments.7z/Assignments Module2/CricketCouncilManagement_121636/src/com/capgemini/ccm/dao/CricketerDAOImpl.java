package com.capgemini.ccm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

import com.capgemini.ccm.bean.Cricketer;
import com.capgemini.ccm.exception.CricketerException;
import com.capgemini.ccm.util.DBUtil;
public class CricketerDAOImpl implements ICricketerDAO {

	@Override
	public int addCricketer(Cricketer cricketer) throws CricketerException {
		int generatedId=-1;
		try(Connection con=DBUtil.getConnection())
		{
			Statement stm=con.createStatement();
			ResultSet res=stm.executeQuery("select cricIDseq.nextVal from dual");
			
			if(res.next()==false)
			{
				throw new CricketerException("Something went wrong while generating a player id ");
			}
		
			int id=res.getInt(1);
		
			String name=cricketer.getName();
			Date dob = cricketer.getDateOfBirth();
			String country=cricketer.getCountry();
			String  battingStyle=cricketer.getBattingStyle();
			int centuries=cricketer.getCenturies();
			int matches=cricketer.getMatches();
			int totalrunscore=cricketer.getTotalRunScore();
			
			PreparedStatement pstm=con.prepareStatement("insert into Cricketer values(?,?,?,?,?,?,?,?)");
			pstm.setInt(1, id);
			pstm.setString(2, name);
			pstm.setDate(3,  dob);
			pstm.setString(4, country);
			pstm.setString(5, battingStyle);
			pstm.setInt(6, centuries);
			pstm.setInt(7, matches);
			pstm.setInt(8, totalrunscore);
			
			pstm.executeUpdate();
			generatedId=id;
			
		}
		catch(SQLException e)
		{
			throw new CricketerException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new CricketerException(e.getMessage());
		}
		return generatedId;
	}

	

	
	@Override
	public void updateCricketer(Cricketer cricketer) throws CricketerException {
		int id = cricketer.getId();
		String name = cricketer.getName();
		Date dob = cricketer.getDateOfBirth();
		String country=cricketer.getCountry();
		String  battingStyle=cricketer.getBattingStyle();
		int centuries=cricketer.getCenturies();
		int matches=cricketer.getMatches();
		int totalrunscore=cricketer.getTotalRunScore();
		
		try(Connection con = DBUtil.getConnection())

		{

		PreparedStatement pstm = con.prepareStatement("update cricketer set name= ?, dob= ?, country= ?, battingStyle= ?, "

		+ "centuries= ?, matches= ?, totalrunscore= ? where id= ? ");

		pstm.setString(1, name);

		pstm.setDate(2, dob);

		pstm.setString(3, country);

		pstm.setString(4, battingStyle);

		pstm.setInt(5, centuries);

		pstm.setInt(6, matches);

		pstm.setInt(7, totalrunscore);

		pstm.setInt(8, id);

		pstm.executeUpdate();

		}

		catch(SQLException e)

		{

		e.printStackTrace();

		throw new CricketerException(e.getMessage());

		}

		catch(Exception e)

		{

		e.printStackTrace();

		throw new CricketerException(e.getMessage());

		}
		
	}

	@Override
	public List<Cricketer> getCricketers() throws CricketerException {
		List<Cricketer> cricketers = new ArrayList<Cricketer>();

		try(Connection con = DBUtil.getConnection())

		{

		Statement stm = con.createStatement();

		ResultSet res = stm.executeQuery("select * from cricketer");

		while(res.next())

		{

		Cricketer cricketer = new Cricketer();

		cricketer.setId(res.getInt("id"));

		cricketer.setName(res.getString("name"));

		cricketer.setDateOfBirth(res.getDate("dob"));

		cricketer.setCountry(res.getString("country"));

		cricketer.setBattingStyle(res.getString("battingstyle"));

		cricketer.setCenturies(res.getInt("ncenturies"));

		cricketer.setMatches(res.getInt("nmatches"));

		cricketer.setTotalRunScore(res.getInt("totalrun"));

		cricketers.add(cricketer);

		}

		}

		catch(SQLException e)

		{

		e.printStackTrace();

		throw new CricketerException(e.getMessage());

		}

		catch(Exception e)

		{

		e.printStackTrace();

		throw new CricketerException(e.getMessage());

		}

		return cricketers;

		}




	@Override
	public Cricketer getCricketer(int id) throws CricketerException {
		Cricketer cricketer = null;

		try(Connection con = DBUtil.getConnection())

		{

		PreparedStatement pstm = con.prepareStatement("Select * from Cricketer where id = ?");

		pstm.setInt(1, id);

		ResultSet res = pstm.executeQuery();

		if(res.next() == false)

		throw new CricketerException("No Cricketer found with id " + id);

		cricketer = new Cricketer();

		cricketer.setId(res.getInt("id"));

		cricketer.setName(res.getString("name"));

		cricketer.setDateOfBirth(res.getDate("dob"));

		cricketer.setCountry(res.getString("country"));

		cricketer.setBattingStyle(res.getString("battingstyle"));

		cricketer.setCenturies(res.getInt("centuries"));

		cricketer.setMatches(res.getInt("matches"));

		cricketer.setTotalRunScore(res.getInt("TotalRunScored"));

		}

		catch(SQLException e)

		{

		e.printStackTrace();

		throw new CricketerException(e.getMessage());

		}

		catch(Exception e)

		{

		e.printStackTrace();

		throw new CricketerException(e.getMessage());

		}

		return cricketer;

		}
	}
		
	
	

	
	
	


