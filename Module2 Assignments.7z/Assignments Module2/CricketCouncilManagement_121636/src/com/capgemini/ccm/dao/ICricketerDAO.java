package com.capgemini.ccm.dao;

import java.util.List;

import com.capgemini.ccm.bean.Cricketer;
import com.capgemini.ccm.exception.CricketerException;



public interface ICricketerDAO {
	public int addCricketer(Cricketer cricketer) throws CricketerException;
	
	public Cricketer getCricketer(int id) throws CricketerException;
	
	public  void updateCricketer(Cricketer cricketer) throws CricketerException;
	
	public List<Cricketer> getCricketers() throws CricketerException;
	

}
