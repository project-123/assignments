package com.capgemini.ccm.service;

import java.util.List;

import com.capgemini.ccm.bean.Cricketer;
import com.capgemini.ccm.dao.CricketerDAOImpl;
import com.capgemini.ccm.dao.ICricketerDAO;
import com.capgemini.ccm.exception.CricketerException;

public class CricketerServiceImpl implements ICricketerService {

	private ICricketerDAO cricketerDAO;
	 public CricketerServiceImpl() {
	
		 cricketerDAO=new CricketerDAOImpl();
	}
	@Override
	public int addCricketer(Cricketer cricketer) throws CricketerException {
		
		return cricketerDAO.addCricketer(cricketer);
	}

	@Override
	public void updateCricketer(Cricketer cricketer) throws CricketerException {
	
		cricketerDAO.updateCricketer(cricketer);
		
	}

	

	@Override
	public List<Cricketer> getCricketers() throws CricketerException {
		
		return cricketerDAO.getCricketers();
	}
	@Override
	public Cricketer getCricketer(int id) throws CricketerException {
		return cricketerDAO.getCricketer(id);
	}
	
	
	
}
