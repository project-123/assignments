package com.capgemini.ccm.view;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.ccm.bean.Cricketer;
import com.capgemini.ccm.exception.CricketerException;
import com.capgemini.ccm.service.CricketerServiceImpl;
import com.capgemini.ccm.service.ICricketerService;

public class CricketerView {
	private ICricketerService cricketerService;

	public CricketerView() {

		cricketerService = new CricketerServiceImpl();

	}

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		CricketerView emsUI = new CricketerView();

		while (true)

		{

			emsUI.showMenu();

			System.out.println();

		}

	}

	private void showMenu() {

		Scanner sc = new Scanner(System.in);

		System.out.println("1) Add Player");

		System.out.println("2) Update Player");

		System.out.println("3)get Player Information");

		System.out.println("4) View All Players");

		System.out.println("5) Exit Application");

		System.out.println("Enter your Choice:");

		int choice = sc.nextInt();

		switch (choice)

		{

		case 1:

			addCricketer();

			break;

		case 2:

			updateCricketer();

			break;

		case 3:

			getCricketer();

			break;

		case 4:

			getCricketers();

			break;

		case 5:

			System.out.println("Thank You! Exiting Application");

			System.exit(0);

			break;

		default:

			System.out.println("Invalid input");

			break;

		}

	}

	private void getCricketers()

	{

		try

		{

			List<Cricketer> cricketer = cricketerService.getCricketers();

			Iterator<Cricketer> it = cricketer.iterator();

			System.out
					.println("ID \t\t Name \t\t DOB \t\t Country \t\t BattingStyle \t\t Centuries \t\t MatchesPlayed \t\t TotalScore");

			while (it.hasNext())

			{

				Cricketer cric = it.next();

				System.out.println(cric.getId() + "\t\t" + cric.getName()
						+ "\t\t" + cric.getDateOfBirth() + "\t\t"
						+ cric.getCountry()

						+ "\t\t" + cric.getBattingStyle() + "\t\t"
						+ cric.getCenturies() + "\t\t" + cric.getMatches()
						+ "\t\t" + cric.getTotalRunScore());

			}

		}

		catch (CricketerException e)

		{

			e.printStackTrace();

		}

		catch (Exception e)

		{

			e.printStackTrace();

		}

	}

	private void updateCricketer()

	{

		Scanner scanner = new Scanner(System.in);

		System.out.println("Updating Player Information");

		System.out.println("\n Player ID: ");

		int id = scanner.nextInt();

		try {

			Cricketer cricketer = cricketerService.getCricketer(id);

			System.out.println("Name: " + cricketer.getName());

			System.out.println("Do you want to update Name (y/n)?");

			char reply = scanner.next().toLowerCase().charAt(0);

			if (reply == 'y')// Updating player Name

			{

				System.out.println("Enter new name: ");

				String name = scanner.next();

				cricketer.setName(name);

			}

			System.out.println("Date Of Birth " + cricketer.getDateOfBirth());

			System.out.println("Do you want to update Date Of Birth ");

			reply = scanner.next().toLowerCase().charAt(0);

			if (reply == 'y')

			{

				System.out.println("Enter Date Of Birth to Update ");

				String dob = scanner.next();

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");

				java.util.Date dt = sdf.parse(dob);

				java.sql.Date date = new Date(dt.getTime());

				cricketer.setDateOfBirth(date);

			}

			System.out.println("Country: " + cricketer.getCountry());

			System.out.println("Do you want to update Country (y/n)?");

			reply = scanner.next().toLowerCase().charAt(0);

			if (reply == 'y')// Updating player Country

			{

				System.out.println("Enter new Country: ");

				String country = scanner.next();

				cricketer.setCountry(country);

			}

			System.out.println("Batting Style: " + cricketer.getBattingStyle());

			System.out.println("Do you want to update Batting Style (y/n)?");

			reply = scanner.next().toLowerCase().charAt(0);

			if (reply == 'y')// Updating player Batting Style

			{

				System.out.println("Enter new Batting Style: ");

				String batsty = scanner.next();

				cricketer.setBattingStyle(batsty);

			}

			System.out.println("No of Centuries: " + cricketer.getCenturies());

			System.out.println("Do you want to update No of Centuries (y/n)?");

			reply = scanner.next().toLowerCase().charAt(0);

			if (reply == 'y')// Updating player No of centuries

			{

				System.out.println("Enter new No of centuries: ");

				int centuries = scanner.nextInt();

				cricketer.setCenturies(centuries);

			}

			System.out.println("No of Matches Played: "
					+ cricketer.getMatches());

			System.out
					.println("Do you want to update No of Matches Played (y/n)?");

			reply = scanner.next().toLowerCase().charAt(0);

			if (reply == 'y')// Updating player No of Matches Played

			{

				System.out.println("Enter new No of Matches Played: ");

				int matches = scanner.nextInt();

				cricketer.setMatches(matches);

			}

			System.out.println("Total Runs Scored: "
					+ cricketer.getTotalRunScore());

			System.out
					.println("Do you want to update No of Total Runs Scored (y/n)?");

			reply = scanner.next().toLowerCase().charAt(0);

			if (reply == 'y')// Updating player Total Runs Scored

			{

				System.out.println("Enter new Total Runs Scored: ");

				int runs = scanner.nextInt();

				cricketer.setTotalRunScore(runs);

			}

			cricketerService.updateCricketer(cricketer);

		}

		catch (CricketerException e)

		{

			e.printStackTrace();

		}

		catch (Exception e)

		{

			e.printStackTrace();

		}

		System.out.print("Updated");

	}

	private void getCricketer()

	{

		Scanner scanner = new Scanner(System.in);

		System.out.println("Retrieving Player Information");

		System.out.println("Enter Player ID ");

		int id = scanner.nextInt();

		try

		{

			Cricketer cricketer = cricketerService.getCricketer(id);

			System.out.println("Player Information");

			System.out.println("ID :" + cricketer.getId());

			System.out.println("Name " + cricketer.getName());

			System.out.println("Date of Birth " + cricketer.getDateOfBirth());

			System.out.println("Country : " + cricketer.getCountry());

			System.out.println("Batting Style :" + cricketer.getBattingStyle());

			System.out.println("Centuries :" + cricketer.getCenturies());

			System.out.println("Matches Played :" + cricketer.getMatches());

			System.out.println("Total Score : " + cricketer.getTotalRunScore());

		}

		catch (CricketerException e)

		{

			e.printStackTrace();

		}

		catch (Exception e)

		{

			e.printStackTrace();

		}

	}

	private void addCricketer()

	{

		Scanner scanner = new Scanner(System.in);

		System.out.println("Adding Player Information");

		System.out.println("Enter Player Name ");

		String name = scanner.next();

		System.out.println("Enter Date Of Birth");

		String dob = scanner.next();

		System.out.println("Enter Country");

		String country = scanner.next();

		System.out.println("Enter Batting Style");

		String batStyle = scanner.next();

		System.out.println("Enter Number of centuries ");

		int centuries = scanner.nextInt();

		System.out.println("Enter Matches Played ");

		int matchPlayed = scanner.nextInt();

		System.out.println("Enter Total Score ");

		int totalScore = scanner.nextInt();

		Cricketer cricketer = new Cricketer();

		cricketer.setName(name);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date dt;

		try

		{

			dt = sdf.parse(dob);

			java.sql.Date date = new Date(dt.getTime());

			cricketer.setDateOfBirth(date);

		}

		catch (Exception e)

		{

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		cricketer.setCountry(country);

		cricketer.setBattingStyle(batStyle);

		cricketer.setCenturies(centuries);

		cricketer.setMatches(matchPlayed);

		cricketer.setTotalRunScore(totalScore);

		cricketerService.addCricketer(cricketer);

	}
}
