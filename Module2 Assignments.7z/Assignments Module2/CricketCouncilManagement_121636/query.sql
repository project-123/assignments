create table Cricketer(id number(6),name varchar2(40),DateOfBirth date,Country varchar2(20),BattingStyle varchar2(50),Centuries number(4),Matches number(5),TotalRunScored number,primary key(id));

create sequence cricIDseq start with 1 increment by 1;
drop table cricketer;

insert into cricketer values(cricIDSeq.nextVal,"Sachin Tendulkar","24-04-1973","India","Right Handed Batsmen",49,463,18426);
select * from cricketer;