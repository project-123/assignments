package com.capgemini.core.ems.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;
import com.capgemini.core.ems.service.EmployeeServiceImpl;
import com.capgemini.core.ems.service.IEmployeeServices;

public class EmployeeView
{

	private IEmployeeServices employeeServices;

	public EmployeeView() 
	{
		employeeServices=new EmployeeServiceImpl();
	}
	public static void main(String[] args) 
	{
		EmployeeView emsUI=new EmployeeView();
		while(true)
		{
			emsUI.showMenu();
		}
	}
	public void showMenu()
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("1) Add Employee");
		System.out.println("2) Get Employee");
		System.out.println("3) Update Employee");
		System.out.println("4) Remove Employee");
		System.out.println("5) Get All Employee");
		System.out.println("6) Exit Application");
		
		System.out.println("Insert your choice");
		int choice=sc.nextInt();
		
		switch (choice) {
		case 1:
			addEmployee();
			
			break;
		case 2:
			getEmployee();
			
			break;
		case 3:
			updateEmployee();
			
			break;
		case 4:
			removeEmployee();
			
			break;
		case 5:
			viewEmployee();
			
			break;
		case 6:
			System.out.println("Thank You! Exiting Application......");
			System.exit(0);
			
			break;

		default:
			System.out.println("Invalid Input");
			break;
		}
		
	}
	
	
	
	
	private void addEmployee() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Provide Employee Information");
		System.out.println("Enter Employee Name");
		String name=sc.next();
		
		System.out.println("Enter Department ");
		String dept=sc.next();
		
		System.out.println("Enter Designation ");
		String desg=sc.next();
		
		System.out.println("Enter salary");
		float salary=sc.nextFloat();
		
		Employee employee=new Employee();
		
		employee.setName(name);
		employee.setDepartment(dept);
		employee.setDesignation(desg);
		employee.setSalary(salary);
		
		
		try{
			int id=employeeServices.addEmployee(employee);
			System.out.println("Employee added successfully with id"+id);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private void getEmployee() {

		
		Scanner sc=new Scanner(System.in);
		System.out.println("Retrieving employee Information");
		System.out.println("\nEmployee ID");
		int id=sc.nextInt();
		try
		{
			Employee employee=employeeServices.getEmployee(id);
			System.out.println("\n******Employee Information******");
			System.out.println("ID: "+employee.getId());
			System.out.println("Name: "+employee.getName());
			System.out.println("Department: "+employee.getDepartment());
			System.out.println("Designation: "+employee.getDesignation());
			System.out.println("Salary: "+employee.getSalary());
			
			System.out.println("\n\n");
			
		
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	private void updateEmployee() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Updating Employee Information");
		System.out.println("\nEmployee Id");
		int id=sc.nextInt();
		
		try
		{
			//attempting to get employee assuming id passed is valid
	
			Employee employee=employeeServices.getEmployee(id);
			//Since employee is retrieved, update it and send it to update employee
			
			System.out.println("Name: "+employee.getName());
			System.out.println("Do you want to update name(y/n)?");
			char reply=sc.next().toLowerCase().charAt(0);
			if(reply=='y')
			{
				System.out.println("Enter New Name");
				String name=sc.next();
				employee.setName(name);
			}
		
			System.out.println("department: "+employee.getDepartment());
			System.out.println("Do you want to update Department(y/n)?");
			reply=sc.next().toLowerCase().charAt(0);
			if(reply=='y')
			{
				System.out.println("Enter New Department");
				String dept=sc.next();
				employee.setDepartment(dept);;
			}
			System.out.println("Designation: "+employee.getDesignation());
			System.out.println("Do you want to update Designation(y/n)?");
			reply=sc.next().toLowerCase().charAt(0);
			if(reply=='y')
			{
				System.out.println("Enter New Designation");
				String desg=sc.next();
				employee.setDesignation(desg);;
			}
			System.out.println("Salary: "+employee.getSalary());
			System.out.println("Do you want to update Salary(y/n)?");
			reply=sc.next().toLowerCase().charAt(0);
			if(reply=='y')
			{
				System.out.println("Enter New Salary");
				float sal=sc.nextFloat();
				employee.setSalary(sal);
			}
			employeeServices.upateEmployee(employee);
			System.out.println("updated Successfully.");
		
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	
	
	
	}
	
	
	
	private void removeEmployee() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Remove Employee Details");
		System.out.println("\nEmployee Id");
		int id=sc.nextInt();
		try
		{
			Employee employee=employeeServices.removeEmployee(id);
			System.out.println("Employee Details removed");
			
			System.out.println("ID: "+employee.getId());
			System.out.println("Name: "+employee.getName());
			System.out.println("Department: "+employee.getDepartment());
			System.out.println("Designation: "+employee.getDesignation());
			System.out.println("Salary: "+employee.getSalary());
			
			System.out.println("\n\n");
			
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
	private void viewEmployee() {
		try{
		
			List<Employee> employees=employeeServices.getEmployees();
			Iterator<Employee> it=employees.iterator();
			
			System.out.println("ID\t Name\t Department\t Designation\t Salary");
			while(it.hasNext())
			{
				Employee employee=it.next();
				System.out.println(employee.getId()+"\t"+employee.getName()+"\t"+employee.getDepartment()+"\t"+employee.getDesignation()+"\t"+employee.getSalary());
			}
			
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
}
