package com.capgemini.core.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;
import com.capgemini.core.ems.util.DBUtil;

public class EmployeeDAOImpl implements IEmployeeDAO
{
	static Logger myLogger;
	
	public EmployeeDAOImpl()
	{
		PropertyConfigurator.configure("log4j.properties");
		myLogger=Logger.getLogger(EmployeeDAOImpl.class.getName());
	}

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		
		
		
	
		int generatedId=-1;
		try(Connection con=DBUtil.getConnection())
		{
			Statement stm=con.createStatement();
			ResultSet res=stm.executeQuery("select empIdSeq.nextVal from dual");
			
			if(res.next()==false)
			{
				throw new EmployeeException("Something went wrong while generating a employee id ");
			}
		
			int id=res.getInt(1);
		
			String name=employee.getName();
			double Salary=employee.getSalary();
			String  dept=employee.getDepartment();
			String desg=employee.getDesignation();
			
			PreparedStatement pstm=con.prepareStatement("insert into employee values(?,?,?,?,?)");
			pstm.setInt(1, id);
			pstm.setString(2, name);
			pstm.setString(3, dept);
			pstm.setString(4, desg);
			pstm.setDouble(5, Salary);
			
			pstm.execute();
			generatedId=id;
			myLogger.info("Employee Added Successfully");
			
		}
		catch(SQLException e)
		{
			
			e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return generatedId;
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		Employee employee=null;
		try(Connection con=DBUtil.getConnection())
		{
		
			PreparedStatement pstm=con.prepareStatement("select * from employee where id=?");
			
			pstm.setInt(1, id);
			
			ResultSet resultSet=pstm.executeQuery();
			
			if(resultSet.next()==false)
			{
				throw new EmployeeException("no employee found with id"+id);
				
			}
			employee=new Employee();
			
			employee.setId(resultSet.getInt(1));
			employee.setName(resultSet.getString(2));
			employee.setDepartment(resultSet.getString(3));
			employee.setDesignation(resultSet.getString(4));
			employee.setSalary(resultSet.getDouble(5));
			
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		
		return employee;
	}

	@Override
	public void upateEmployee(Employee employee) throws EmployeeException {
		try(Connection con=DBUtil.getConnection())
		{
			int id=employee.getId();
			String name=employee.getName();
			String dept=employee.getDepartment();
			String desg=employee.getDesignation();
			double salary=employee.getSalary();
			PreparedStatement pstm=con.prepareStatement("update employee set name=?,department=?,designation=?,salary=? where id=?");
			pstm.setString(1, name);
			pstm.setString(2, dept);
			pstm.setString(3, desg);
			pstm.setDouble(4, salary);
			pstm.setInt(5, id);
			pstm.execute();
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
	}

	@Override
	public Employee removeEmployee(int id) throws EmployeeException {
		Employee employee=null;
		
		try(Connection con=DBUtil.getConnection())
		{
			employee=getEmployee(id);
			if(employee==null)
			{
				throw new EmployeeException("Employee id does not exist with this id: "+id);
			}
			
			PreparedStatement pstm=con.prepareStatement("delete from employee where id=?");
			pstm.setInt(1, id);
			
			pstm.execute();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
		return employee;
	}

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		List<Employee> employees=new ArrayList();
		
		try(Connection con=DBUtil.getConnection())
		{
			Statement stm=con.createStatement();
			ResultSet res=stm.executeQuery("select * from employee");
			while(res.next())
			{
				Employee employee=new Employee();
				employee.setId(res.getInt(1));
				employee.setName(res.getString(2));
				employee.setDepartment(res.getString(3));
				employee.setDesignation(res.getString(4));
				employee.setSalary(res.getDouble(5));
				employees.add(employee);
			}
			
			
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		return employees;
	}

}
