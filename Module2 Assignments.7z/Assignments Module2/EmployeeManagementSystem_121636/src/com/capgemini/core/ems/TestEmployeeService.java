package com.capgemini.core.ems;

import java.util.List;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.service.EmployeeServiceImpl;

public class TestEmployeeService {

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EmployeeServiceImpl employeeService=new EmployeeServiceImpl();
	
		//Testing addEmployee object
		/*Employee employee=new Employee();
		employee.setDepartment("Management");
		employee.setName("John");
		employee.setDesignation("Admin");
		employee.setSalary(55000);
		
		employeeService.addEmployee(employee);*/
		//end of testing addEmployee method
		
		//================================================//
		
		//test getEmployee method
		
		//Employee emp=employeeService.getEmployee(1021);
		//System.out.println(emp);
		
		
		//test updateEmployee
		
		/*Employee employee=new Employee();
		employee.setId(1021);
		employee.setDepartment("IT");
		employee.setName("Aakash");
		employee.setDesignation("Sr.JavaDev");
		employee.setSalary(36000);
		
		employeeService.upateEmployee(employee);*/
		
		
		//end of update emp;
		
		//test emove mep;
		
		/*Employee emp=employeeService.removeEmployee(1020);
		System.out.println("Employee removed");
		System.out.println(emp);
		System.out.println();*/
		
		
		//Test getEmployees method
	/*	
	List<Employee> emps=employeeService.getEmployees();
		for(Employee employee:emps)
	{
			System.out.println(employee);
		}
		//end of test getEmployees

*/
		}
}
