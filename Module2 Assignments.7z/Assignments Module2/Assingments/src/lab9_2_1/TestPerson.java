package lab9_2_1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestPerson {

	@Test
	public void testGetFullName() {
		System.out.println("from TestPerson2");
		Person p = new Person("Robert", "King");
		assertEquals("Robert King",p.getFullName());
	}

	@Test
	public void testGetFirstName() {
		System.out.println("from TestPerson2");
		Person p = new Person("Robert", "King");
		assertEquals("Robert",p.getFirstName());
	}

	@Test
	public void testGetLastName() {
		System.out.println("from TestPerson2");
		Person p = new Person("Robert", "King");
		assertEquals("King",p.getLastName());
	}

	@Test
	public void testDisplay() {
		System.out.println("from TestPerson2");
		Person p = new Person("Robert", "King");
		assertEquals("Robert King",p.display());
	}

	
}
