package lab8_3;

import java.io.*;


public class Service {


		public static void main(String[] args) {

		// TODO Auto-generated method stub

		//BufferedWriter

		BufferedWriter bufferedWriter=null;

		Person p1=new Person();

		p1= new Person("Aakash","Kharde",'M',9892926218L);

		try 
		{

		bufferedWriter=new BufferedWriter(

		new FileWriter("D:/Aakash/Module_2/PersonInfo.txt"));

		bufferedWriter.write(p1.getFirstName()+",");

		bufferedWriter.write(p1.getLastName()+",");

		bufferedWriter.write(p1.getGender()+",");

		bufferedWriter.write(String.valueOf(p1.getMobileno()));

		} catch (FileNotFoundException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		} catch (IOException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		catch(Exception e)

		{

		e.printStackTrace();

		}

		finally{

		if(bufferedWriter!=null)

		{

		try {

		bufferedWriter.close();

		} catch (IOException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		}

		}

		//BufferedReader

		BufferedReader bufferedReader=null;

		try {

		bufferedReader=new BufferedReader(

		new FileReader("D:/Aakash/Module_2/PersonInfo.txt"));

		int count=0;

		String line=bufferedReader.readLine();

		while(line!=null)

		{

		System.out.println(line);

		line=bufferedReader.readLine();

		count++;

		}

		} catch (FileNotFoundException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		} catch (IOException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		catch(Exception e)

		{

		e.printStackTrace();

		}

		finally{

		if(bufferedReader!=null)

		{

		try {

		bufferedReader.close();

		} catch (IOException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

		}

		}

		}

		}
