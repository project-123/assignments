package lab6_2;

public class AgeException extends Exception{

	public AgeException()
	{

		System.out.print("Age should be greater than 15");

	}

	public String toString()
	{

		return ":Age Exception";

	}

}