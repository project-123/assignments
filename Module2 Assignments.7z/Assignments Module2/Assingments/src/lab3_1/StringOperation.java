package lab3_1;
import java.util.*;

public class StringOperation {

	static Scanner sc = new Scanner(System.in);
	public void operation(String s)
	{
	
		System.out.println("Following Are The Operations You Can Perform");
		System.out.println("-----------------------------------------");
		System.out.println("1. Add The String To Itself");
		System.out.println("2. Replace Odd Positions With #");
		System.out.println("3. Remove Duplicate Characters In The String");
		System.out.println("4. Change Odd Characters To Upper Case ");
		System.out.println("-----------------------------------------");
		System.out.println("Select Any One Option From The List Above");

		int a = sc.nextInt();
		int i;
		
		switch(a)
		{
		case 1:String str=s;
		
			str += s;
			System.out.println("After Adding The String"+str);
			break;
			
		case 2: String str1 = s;
			char[] aa = str1.toCharArray();
			String wrd="";
			for(i=0;i<aa.length;i+=2)
			{
				
			}
			
			System.out.println("After Replacing "+str1);
			
			break;
			
		case 3: String str2 = s;
				char [] chararray = str2.toCharArray();
				
				for ( i=0;i<chararray.length;i++)
				{
					char chr =chararray[i];
					for(int j =i+1;j<chararray.length;j++)
					{
						char chr1 = chararray[j];
						if(chr == chr1)
						{
							chararray[j]='\0';
						}
					}
				}
		
				String abc = "";
				for(i=0;i<chararray.length;i++)
				{
					if(chararray[i] != '\0')
					{
						abc += chararray[i];
					}
				}
				System.out.println("Removing Duplicates "+abc);
				break;
			
		case 4:String str3 = s;
			String temp ="";
			String Word = "";
			
			for(i = 0;i<str3.length();i++)
			{
				if(i % 2 == 0)
				{
					temp="";
					temp += str3.charAt(i);
					temp = temp.toLowerCase();
					Word += temp;
				}
				else
				{
					temp="";
					temp += str3.charAt(i);
					temp = temp.toUpperCase();
					Word += temp;
				}
			}
			
			System.out.println("Replacing....");
			System.out.println(Word);
			break;
				
		
			
		}

	}
	public static void main(String[] args)
	
	{
		StringOperation op = new StringOperation();
		System.out.println("Enter A String");
		String strr = sc.nextLine();
		
		op.operation(strr);
	}

}
