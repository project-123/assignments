package lab2_5;


public class Person {

	private String firstName;
	private String lastName;
	private char gender;
	private long Mobileno;

	

	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}
	

	

	public long getMobileno() {
		return Mobileno;
	}

	public void setMobileno(long mobileno) {
		Mobileno = mobileno;
	}

	

	public Person(String firstName, String lastName, char gender, long mobileno) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		Mobileno = mobileno;
	}

	public Person(){
		
	}
	
	public void display()
	{
		
		
		System.out.println("Gender  "+gender);
		
		
	}

	
	
	
}

