package lab4_Total;



public class AccountDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Person person1 = new Person();
		
		person1.setName("Smith");
		person1.setAge(22);
		
		Person person2=new Person();
		
		person2.setName("Kathy");
		person2.setAge(18);
		
		/* Account account1= new Account();
		
		account1.setPerson(person1);
		account1.setAccountNo(1221112);
		account1.setBalance(2000);
		
		Account account2=new Account();
		
		account2.setPerson(person2);
		account2.setAccountNo(1233112);
		account2.setBalance(3000); 
		
		account1.deposit(2000);
		System.out.println("Balance of smith "+account1.getBalance());
		
		account2.withdraw(2000);
		System.out.println("Balance Of Kathy"+account2.getBalance());
		
		account2.withdraw(2000);
		System.out.println("Balance Of Kathy"+account2.getBalance());
		
		System.out.println(account1);
		System.out.println(account2); */
		
		SavingAccount sa = new SavingAccount(7899,50000,person1,10000);
		
		sa.deposit(30000);
		System.out.println("Account Details"+sa);
		
		sa.withdraw(40000);
		System.out.println("Account Details"+sa);
		
		sa.withdraw(20000);
		System.out.println("Account Details"+sa);
		sa.withdraw(20000);
		System.out.println("Account Details"+sa);
		
		CurrentAccount ca = new CurrentAccount(7898,60000,person2,120000);
		
		ca.withdraw(130000);
		System.out.println("Account Details"+ca);
		ca.withdraw(20000);
		System.out.println("Account Details"+ca);
		
		
	}
	
	
	
}
