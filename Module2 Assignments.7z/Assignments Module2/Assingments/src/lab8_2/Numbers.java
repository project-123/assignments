package lab8_2;

import java.io.*;
import java.util.*;

public class Numbers {

public static void main(String[] args)

{


	BufferedReader bufferedReader=null;

	try
	{

		bufferedReader=new BufferedReader(

		new FileReader("D:/Aakash/Module_2/NumbersLab8.2.txt"));

		String line=bufferedReader.readLine();

		String num[]=line.split(",");

		//int num1[];

		while(line!=null)

		{

			for(int i=0;i<num.length;i++)

			{

				int num1=Integer.valueOf(num[i]);

				if(num1%2==0)

				{

					System.out.println(num[i]);

				}

			}

			//	System.out.println(line);

			line=bufferedReader.readLine();

			}

		}
		
		catch (FileNotFoundException e) 
		{


			e.printStackTrace();

		}
		catch (IOException e) 
		{

			e.printStackTrace();

		}

		catch(Exception e)

		{

			e.printStackTrace();

		}

		finally
		
		{

			if(bufferedReader!=null)

			{

				try 
				{

					bufferedReader.close();

				}
				catch (IOException e) 
				{

					e.printStackTrace();

				}

			}

		}

	}

}