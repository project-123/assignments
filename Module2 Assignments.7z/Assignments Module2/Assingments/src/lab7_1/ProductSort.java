package lab7_1;

import java.util.Arrays;
public class ProductSort
{

	public static void sort(String [] args)

	{

	Arrays.sort(args);

	for(int i=0;i<args.length;i++)

	{

	System.out.println(args[i]);

	}

	}

	public static void main(String [] args)

	{

	String[] products = {"Shirt","Pant","Jeans","Sword"};

	sort(products);

	}

	}



