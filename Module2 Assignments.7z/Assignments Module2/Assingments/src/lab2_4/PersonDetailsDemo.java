package lab2_4;

import lab2_3.Person;



public class PersonDetailsDemo {

	public static void main(String[] args) {
	


		PersonDetails p; 
		p = new PersonDetails("Aakash","Kharde",9892926218l);
		
		p.display();
	}

}
