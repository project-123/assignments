package lab2_4;


public class PersonDetails {

	public String firstName;
	public String lastName;
	public long PhoneNo;
	
	
	
	
	public PersonDetails(String firstName, String lastName, long phoneNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		PhoneNo = phoneNo;
	}




	public void display()
	{
		
		System.out.println("First Name  "+firstName);
		System.out.println("Last Name  "+lastName);
		System.out.println("Phone No  "+PhoneNo);
		
	}
	
	
}
