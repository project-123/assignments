package com.cg.eis.bean;



public class Employee {

		private int EmpId;
		private String EmpName;
		private double Salary;
		private String EmpDesignation;
		private String InsuranceScheme;
		public int getEmpId() {
			return EmpId;
		}
		public void setEmpId(int empId) {
			EmpId = empId;
		}
		public String getEmpName() {
			return EmpName;
		}
		public void setEmpName(String empName) {
			EmpName = empName;
		}
		public double getSalary() {
			return Salary;
		}
		public void setSalary(double salary) {
			Salary = salary;
		}
		public String getEmpDesignation() {
			return EmpDesignation;
		}
		public void setEmpDesignation(String empDesignation) {
			EmpDesignation = empDesignation;
		}
		public String getInsuranceScheme() {
			return InsuranceScheme;
		}
		public void setInsuranceScheme(String insuranceScheme) {
			InsuranceScheme = insuranceScheme;
		}
		public Employee(int empId, String empName, double salary,
				String empDesignation, String insuranceScheme) {
			super();
			this.EmpId = empId;
			this.EmpName = empName;
			this.Salary = salary;
			this.EmpDesignation = empDesignation;
			this.InsuranceScheme = insuranceScheme;
		}
		public Employee() {
			// TODO Auto-generated constructor stub
		}
		
		
		
		
}
