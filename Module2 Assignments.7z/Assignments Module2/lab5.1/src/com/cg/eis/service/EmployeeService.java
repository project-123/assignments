package com.cg.eis.service;
import com.cg.eis.bean.*;

public interface EmployeeService {

	public void displayDetails(Employee emp);
	public  String findScheme(double Salary,String Designation);
	public Employee getEmployeeDetails();
}
