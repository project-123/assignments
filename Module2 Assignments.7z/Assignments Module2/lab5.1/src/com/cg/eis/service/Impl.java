package com.cg.eis.service;
import com.cg.eis.bean.*;
import java.util.*;

public class Impl implements EmployeeService {

	@Override
	public Employee getEmployeeDetails() {

		Employee emp = new Employee();
	
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter EmployeeId");
	int eid = sc.nextInt();
	System.out.println("Enter Employee Name");
	String eName = sc.next();
	System.out.println("Enter Employee Salary");
	double Sal = sc.nextDouble();
	System.out.println("Enter Employee Designation");
	String eDesg = sc.next();
	
		emp.setEmpId(eid);
		emp.setEmpName(eName);
		emp.setSalary(Sal);
		emp.setEmpDesignation(eDesg);
			
		
		
		return emp;
	}
	
	@Override
	public String findScheme(double Salary, String Designation) {
		// TODO Auto-generated method stub
		return null;


}

	@Override
	public void displayDetails(Employee emp) {
		// TODO Auto-generated method stub
		System.out.println("Employee Id "+emp.getEmpId());
		System.out.println("Employee Name "+emp.getEmpName());
		System.out.println("Employee Salary "+emp.getSalary());
		System.out.println("Employee Designation "+emp.getEmpDesignation());
	}

	

	
}
